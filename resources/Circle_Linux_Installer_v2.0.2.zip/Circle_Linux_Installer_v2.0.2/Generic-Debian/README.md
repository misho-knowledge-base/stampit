Readme for AB Circle CCID Smart Card Reader Driver.
===================================================

This library provides a PC/SC IFD handler implementation for the AB Circle 
USB smart card readers compliant to the CCID protocol. This package will 
enable communications with all ABC CCID smartcard readers through the 
PC/SC Lite resource manager (pcscd). 

To install abcccid, either:
- Open the .deb file using a Software Manager or Package Installer and 
  follow the instructions.
- Open a terminal window and typing "dpkg -i <driver-package>.deb"

Note:
In order for PC/SC to be used, the PC/SC Lite resource manager (pcscd)
should be installed as well. This can be done through a terminal window
and typing "sudo apt install pcscd".

Supported operating systems:
============================

- Linux Debian 10 (buster)
- Linux Debian 9 (stretch)
- Linux Ubuntu 19.10 (Eoan Ermine)
- Linux Ubuntu 19.04 (Disco Dingo)
- Linux Ubuntu 18.04 (Bionic Beaver)
- Linux Ubuntu 16.04 (Xenial Xerus)
- Linux Ubuntu 14.04 (Trusty Tahr)
- Linux Mint 19.1 (Tessa)

Note: 
Older Debian releases or additional Debian-based OSes should work as well, 
but are un-tested at this time.

Licence:
========

  This library is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at
your option) any later version.

  This library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


History:
========

2.0.2                            28 May 2020
--------------------------------------------
-    Improved behaviour of ifsc and ifsd setting for T=1 protocol
-    Don't send SetParameters for card using default speed.
-    Fixed issue in T=1 IFS max frame length setting.

2.0.1                       03 February 2020
--------------------------------------------
-    Added support for Escape Command IO Control Code 3500.

2.0.0                        15 October 2019
--------------------------------------------
-    Removed PPS call for all ABC readers (use CCID_SetParameters only).
-    Implemented new reader names.

1.0.1                      04 September 2019
--------------------------------------------
-    Always start multi-slot card detection thread as on MacOS X Mojave pcscd is 
     not used anymore (thus treat all readers as multi-slot).  
-    Merged changes from the latest generic ccid package 1.4.3x from Ludovic Rousseau
     (https://ccid.apdu.fr/)  

1.0.0                         16 August 2019
--------------------------------------------
-    Initial release  
-    Based on the generic ccid package 1.4.30 from Ludovic Rousseau (https://ccid.apdu.fr/)  
-    Added support for:  
     -    Circle CIR115 ICC  
     -    Circle CIR215 PICC  
     -    Circle CIR215 CL  
     -    Circle CIR315 Dual & 1S  
     -    Circle CIR315 PICC  
     -    Circle CIR315 SAM  
     -    Circle CIR315 CL  
     -    Circle CIR315 DI  
     -    Circle CIR415 CL & 1S  
     Readers.  
-    Fixed issue of TPDU pps being sent to APDU reader.

===================================================
(c) 2019-2020, AB Circle Limited